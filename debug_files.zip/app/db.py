import psycopg2
from psycopg2.extras import RealDictCursor
from contextlib import contextmanager
from app.config import Config


def get_db_connection():
    """
    Create a new PostgreSQL database connection
    """

    try:

        conn = psycopg2.connect(
            dbname=Config.DB_NAME,
            user=Config.DB_USER,
            password=Config.DB_PASSWORD,
            host=Config.DB_HOST,
            port=Config.DB_PORT,
            cursor_factory=RealDictCursor,
            connect_timeout=5
        )

        return conn

    except Exception as e:

        print("Database Connection Error:", str(e))
        raise e


@contextmanager
def get_cursor():
    """
    Production safe cursor manager
    Automatically commits or rollbacks transactions
    """

    conn = get_db_connection()
    cursor = conn.cursor()

    try:

        yield cursor
        conn.commit()

    except Exception as e:

        conn.rollback()
        print("Database Transaction Error:", str(e))
        raise e

    finally:

        cursor.close()
        conn.close()
